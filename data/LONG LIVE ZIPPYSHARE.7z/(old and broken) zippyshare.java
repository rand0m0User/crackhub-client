package CrackhubClient;

import java.nio.file.Files;
import static CrackhubClient.util.*;

public class zippyshare {

    //VARS
    public static String[] URLS;
    private static String URL;

    private boolean DetectedMethod = false;

    //used for batch script generation
    private static String[] BATINFO;
    private static String[] BATURLS;
    private static int BUPos = 0;
    private boolean desktop = false;

    private static boolean GenerateBat = false;

    //CONFIG:
    private static boolean UseSystemDownlads = true;

    //STRUCT: configuration
    public static String OldDomainSeperator = "/v/";
    public static String domainSeperator = "/d/";
    public static String seperator = ": ";
    //public static String OldLineOfInterest = "document.getElementById('fimage').href = ";
    public static String LineOfInterest = "document.getElementById('dlbutton').href";

    //ENUM: downloader type
    //1: CURL
    //2: BAT
    public static int DLType = 1; //default value is CURL

    public static void init(String URLS_in_file) {
        URLS = load(URLS_in_file.replace("\"", "")).split("\n");
    }

    public static void init(String[] in) {
        URLS = in;
    }

    public void test(String link) {
        try {
            String f = "testFile: " + link;
            URLS = new String[]{f};
            run(1, false, true, "testFile.bin");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void SetDesktop() {
        desktop = true;
    }

    public void run(
            int dlt, //DL type, 1 = direct, 2 = batch
            boolean quiet, //dont print anything to the console
            boolean nodir, //use program root to download files to
            String outname //name of output file
    ) throws Exception {    //veralog formatting
        DLType = dlt;
        if (DLType == 2) {
            GenerateBat = true;
            BATURLS = new String[URLS.length];
            BATINFO = new String[URLS.length];
        } else {
            GenerateBat = false; //doubble fix
        }
        String out;
        if (UseSystemDownlads) {
            out = "..\\..\\..\\Downloads\\" + outname + "\\";
        } else {
            out = "out\\" + outname + "\\";
        }

        if (!nodir && UseSystemDownlads) {
            createCanonicalFile(out).mkdir();
            save(out + "arc.exe", loadbytearr("..\\..\\__NBP_tools_dir__\\arc.exe"));
            save(out + "unpack.bat", loadbytearr("..\\..\\__NBP_tools_dir__\\unpack.bat"));
            //never forget to actually save an object under a file name
        }

        int counter = 0;
        for (int u = 0; u < URLS.length; u++) {
            String fname = URLS[u].split(seperator)[0];
            try {
                if (!Files.exists(createCanonicalFile(out + fname).toPath())) {
                    URL = URLS[u].split(seperator)[1];
                    if (quiet) {
                        print("[zippyshare downloader]: fetching page from: " + URL);
                    }
                    curl(URL, "zippyshare.html");
                    String[] file = new String(Files.readAllBytes(createCanonicalFile("zippyshare.html").toPath())).split("\n");
                    boolean LineOfInterestFound = false;
                    boolean thirdMethod = false;
                    boolean fourthMethod = false;
                    boolean fithMethod = false;
                    int a = 0;
                    int b = 0;
                    int c = 0;
                    int d = 0;
                    int omg = 0;
                    //MAIN LOOP
                    for (int i = 150; i < file.length; i++) {
                        String filei = file[i];
                        //a seems to allways be 3, not shure if i should 
                        //hard code it to 3 or if this ' "asdasd".substr(0, 3) ' 
                        //value will change in the future...
                        if (filei.contains("    var a = ") && !file[i].contains("navigator")) { //grab a
                            try {
                                a = Integer.valueOf(filei.split(" = ")[1].replace(';', ' ').trim());
                            } catch (Exception e) {
                                if (!DetectedMethod) {
                                    print("[zippyshare downloader]: link obfuscation method 3 detected");
                                    DetectedMethod = true;
                                }
                                a = 1;//Integer.valueOf(filei.split("return")[1].replace("};", "").trim());
                                b = a + 1;//Integer.valueOf(file[i + 1].split("return a() +")[1].replace("};", "").trim());
                                c = b + 1;//Integer.valueOf(file[i + 2].split("return b() +")[1].replace("};", "").trim());
                                thirdMethod = true;
                            }
                        }
                        if (filei.contains("<span id=\"omg\" class=\"")) { //grab d
                            d = Integer.valueOf(filei.split("\"")[3]);
                            d = d * 2;
                        }
//                        if (filei.contains("var b = parseInt(document.getElementById('dlbutton').omg) * (")) {
//                            //       var b = parseInt(document.getElementById('dlbutton').omg) * (428683%3);
//                            b = Integer.valueOf((filei.split("(")[3]).split("%")[0]) % Integer.valueOf((filei.split("(")[3]).split("%")[1]);
//                            print("[zippyshare downloader]: link obfuscation method 5 detected");
//                        }
                        if (filei.contains("var b = parseInt(document.getElementById('dlbutton').omg)")) {
                            b = omg * Integer.valueOf(filei.split(" * ")[1].split("%")[0].substring(1)) % 3;
                        }
                        if (filei.contains("document.getElementById('dlbutton').omg = ")) { //grab b
                            try {
                                b = file[i].split("\"")[1].subSequence(0, 3).length();
                            } catch (Exception e) {
                                if (filei.split("=")[1].contains("%")) { //document.getElementById('dlbutton').omg = <val>%<val2>;
                                    String[] p = filei.split("=")[1].split("%");
                                    omg = Integer.valueOf(p[0]) % Integer.valueOf(p[1]);
                                    fithMethod = true;
                                    if (!DetectedMethod) {
                                        print("[zippyshare downloader]: link obfuscation method 5 detected");
                                        DetectedMethod = true;
                                    }
                                    continue;
                                }

                                b = Integer.valueOf(file[i - 1].split(" = ")[1].replace(';', ' ').trim());
                                //a = (int) Math.floor(a / 3);
                                fourthMethod = true;
                                if (!DetectedMethod) {
                                    print("[zippyshare downloader]: link obfuscation method 4 detected");
                                    DetectedMethod = true;
                                }

                            }
                        }
                        if (filei.contains(LineOfInterest)) {
                            if (filei.split("////")[2].length() < 3) {
                                continue;
                            }
                            LineOfInterestFound = true;
                            try {
                                solvemath(filei); //DO NOT! remove the backward compatability!
                                if (!DetectedMethod) {
                                    print("[zippyshare downloader]: link obfuscation method 1 detected");
                                    DetectedMethod = true;
                                }
                            } catch (Exception e) {
                                String[] lns = filei.split("\"");
                                if (fithMethod) {
                                    //<script type="text/javascript">
                                    //   var otfunction = function() {
                                    //       document.getElementById('fimage').href  = '';
                                    //   };
                                    //   var somffunction = function() {
                                    //       var a = 783706;
                                    //       document.getElementById('dlbutton').omg = 783709%78956;
                                    //       var b = parseInt(document.getElementById('dlbutton').omg) * (783709%3);
                                    //       var e = function() {if (false) {return a+b+c} else {return (a+3)%b + 3}};
                                    //       document.getElementById('dlbutton').href    = "/d/5wua899i/"+(b+18)+"/fckdrm-civitatem.nfo";
                                    //       if (document.getElementById('fimage')) {
                                    //           document.getElementById('fimage').href  = "/i/5wua899i/"+(b+18)+"/fckdrm-civitatem.nfo";
                                    //       }
                                    //       var result = 0;
                                    //   };
                                    //</script>
                                    URL = URLS[u].split(OldDomainSeperator)[0].split(": ")[1]
                                            + filei.split("\"")[1]
                                            + b + 18
                                            + filei.split("\"")[3];

                                }
                                if (!thirdMethod) {
                                    if (fourthMethod) {
                                        //document.getElementById('dlbutton').href = "/d/GeP2o0nM/"+(a + 686087%b)+"/darksiders.nfo";
                                        //String obfs = Double.toString((Math.floor(a / 3)) + Integer.valueOf(filei.trim().split(" ")[4].split("%")[0]) % b);
                                        //try {
                                        //obfs = Integer.valueOf(obfs.replace('.', 'a').split("a")[0]) + "";
                                        //} catch (Exception obferr) {
                                        //ignore the error if its a whole number
                                        //}
                                        //print(obfs);
                                        URL = URLS[u].split(OldDomainSeperator)[0].split(": ")[1]
                                                + filei.split("\"")[1]
                                                + Integer.valueOf(Double.toString((Math.floor(a / 3)) + Integer.valueOf(filei.trim().split(" ")[4].split("%")[0]) % b).replace('.', 'a').split("a")[0])
                                                + filei.split("\"")[3];
                                    } else {
                                        if (!DetectedMethod) {
                                            print("[zippyshare downloader]: link obfuscation method 2 detected");
                                            DetectedMethod = true;
                                        }
                                        //assemble the URL from all of the parsed information
                                        URL = URLS[u].split(OldDomainSeperator)[0].split(": ")[1]
                                                + lns[1]
                                                + (int) (Math.pow(a, 3) + b)
                                                + lns[3];
                                    }
                                } else {
                                    //print(filei);
                                    URL = URLS[u].split(OldDomainSeperator)[0].split(": ")[1]
                                            + filei.split("\"")[1]
                                            + (int) (Integer.valueOf(filei.split("\"")[2].replace("+(", "").split("%")[0])
                                            % Integer.valueOf(filei.split("\"")[2].replace("+(", "").split("%")[1].split(" ")[0])
                                            + a + b + c + d + 5 / 5)
                                            + filei.split("\"")[3];
                                }
                            }
                            if (GenerateBat) {
                                String tmp = "echo \"" + ProgressBar(counter) + "downloading: " + URL + "\"";
                                BATINFO[counter] = tmp;
                                print("[zippyshare downloader][bat generation]: " + tmp);
                            } else {
                                if (quiet) {
                                    print(ProgressBar(u) + "downloading: " + URL);
                                }
                            }
                            if (nodir) { //nodir. useed for printing the NFO
                                download(URL, fname);
                            } else {
                                if (desktop) {
                                    download(URL, "..\\Downloads\\" + outname + "\\" + fname);
                                } else {
                                    download(URL, out + fname);
                                }
                            }
                            //break;
                        }
                        if (i == file.length - 1 && !LineOfInterestFound) {
                            if (quiet) {
                                print("[zippyshare downloader/ERROR] link is dead!");
                            }
                            LineOfInterestFound = false;
                        }

                    }
                } else {
                    if (quiet) {
                        print(URLS[u].split(seperator)[0] + " allready exists");
                        BUPos++;
                    }
                }
            } catch (Exception e) {
                print("[WARNING] ignoring: \"" + fname + "\"");
                //counter++;
            }
            counter++;
        }
        if (GenerateBat) {
            String bat = "@echo off\ncolor 0a\n";
            for (int i = 0; i < URLS.length; i++) {
                if (BATINFO[i] != null) {
                    bat += BATINFO[i] + "\n";
                    bat += BATURLS[i] + "\n";
                }
            }
            bat += "pause";
            if (desktop) {
                save("..\\..\\..\\Desktop\\" + outname + "_generated.bat", bat);
            } else {
                save(outname + "_generated.bat", bat);
            }
            BATINFO = null;
            BUPos = 0; // potential fix for a AIOB bug
            BATURLS = null;

            //shellexec("cmd /c run \"..\\..\\..\\Desktop\\" + outname + "_generated.bat\"");
        }
    }

    private void download(String URL, String fileName) throws Exception {
        switch (DLType) {
            case 1:
                curl(URL, fileName);
                break;
            case 2:
                if (desktop) {
                    BATURLS[BUPos] = "..\\Documents\\__NBP_tools_dir__\\curl\\curl -k -L -o \".\\" + fileName + "\" \"" + URL + "\"";
                } else {
                    BATURLS[BUPos] = "..\\..\\__NBP_tools_dir__\\curl\\curl -k -L -o \".\\" + fileName + "\" \"" + URL + "\"";
                }
                BUPos++;
                break;
            //default:
            //print(curld(URL, fileName));
        }
    }

    //old method for deobfuscateing the download URL
    private static void solvemath(String in) throws Exception {
        String domain = URL.split(OldDomainSeperator)[0];
        String[] parts = in.split("\"");
        String[] SMP = parts[2].replace("(", "").replace(")", "").split(" ");
        int solved = Integer.valueOf(SMP[2]) % Integer.valueOf(SMP[4]) + Integer.valueOf(SMP[6]) % Integer.valueOf(SMP[8]);
        URL = domain + parts[1] + solved + parts[3];
    }

    private static String ProgressBar(int progress) {
        int len = URLS.length;
        progress++;
        return "[" + progress + "/" + len + "](" + ((float) progress / len) * 100f + "%) ";
    }

//    private static void shellexec(String cmd) throws Exception {
//        print(cmd);
//        Process p = Runtime.getRuntime().exec(cmd);
//        int result = p.waitFor();
//    }
}
