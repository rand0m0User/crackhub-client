package CrackhubClient.providers.zippyshareLinkObfuscation;

import static CrackhubClient.util.print;

public class obf1 {

    public static boolean debug = false;

//    private static void deb(String ln) {
//        if (debug) {
//            print(ln);
//        }
//    }

    private static final String LineOfInterest = "document.getElementById('dlbutton').href";

    public static String getlink(String link, String[] page) {
        try {
            for (int i = 150; i < page.length; i++) {
                String filei = page[i].trim();
                if (filei.contains(LineOfInterest)) {
                    String domain = link.split(": ")[1].split("/v/")[0];
                    String[] parts = filei.split("\"");
                    String[] SMP = parts[2].replace("(", "").replace(")", "").split(" ");
                    int solved = Integer.valueOf(SMP[2]) % Integer.valueOf(SMP[4]) + Integer.valueOf(SMP[6]) % Integer.valueOf(SMP[8]);
                    return domain + parts[1] + solved + parts[3];
                }
            }
            return null;
        } catch (Exception e) {
            if (debug) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
