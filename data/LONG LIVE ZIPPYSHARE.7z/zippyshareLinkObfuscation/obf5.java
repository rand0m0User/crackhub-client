package CrackhubClient.providers.zippyshareLinkObfuscation;

import static CrackhubClient.util.createCanonicalFile;
import static CrackhubClient.util.curl;
import static CrackhubClient.util.print;
import java.nio.file.Files;

//zippyshare link obfuscation method number 5, bug included!

//<script type="text/javascript">
//   var otfunction = function() {
//       document.getElementById('fimage').href  = '';
//   };
//   var somffunction = function() {
//       var a = 783706;
//       document.getElementById('dlbutton').omg = 783709%78956;
//       var b = parseInt(document.getElementById('dlbutton').omg) * (783709%3);
//       var e = function() {if (false) {return a+b+c} else {return (a+3)%b + 3}};
//       document.getElementById('dlbutton').href    = "/d/5wua899i/"+(b+18)+"/fckdrm-civitatem.nfo";
//       if (document.getElementById('fimage')) {
//           document.getElementById('fimage').href  = "/i/5wua899i/"+(b+18)+"/fckdrm-civitatem.nfo";
//       }
//       var result = 0;
//   };
//</script>
public class obf5 {

    public static boolean debug = false;

    private static void deb(String ln) {
        if (debug) {
            print(ln);
        }
    }

    private static int b = 0;
    private static int omg = 0;

    private static final String LineOfInterest = "document.getElementById('dlbutton').href";

    public static String getlink(String link, String[] page) {
        try {
            byte flags = 0;
            int count = 0;
            for (int i = 150; i < page.length; i++) {
                String filei = page[i].trim();
                if (filei.contains("document.getElementById('dlbutton').omg =")) {
                    deb(filei);
                    flags |= 1;
                    omg = Integer.valueOf(filei.split("=")[1].split("%")[0].trim()) % 78956; //constant
                }
                if (filei.contains("var b = parseInt(document.getElementById('dlbutton').omg)")) {
                    deb(filei);
                    flags |= 2;
                    int num = Integer.valueOf(filei.split(" ")[5].split("%")[0].replace('(', ' ').trim());
                    b = omg * (num % 3);
                    if (b == 0) {
                        //"cope" with the bug in zippyshare's backend code
                        print("[zippyshare downloader] zippyshare developers suck at math");
                        Files.delete(createCanonicalFile("zippyshare.html").toPath());
                        curl(link.split(": ")[1], "zippyshare.html"); //re roll the numbers
                        page = new String(Files.readAllBytes(createCanonicalFile("zippyshare.html").toPath())).split("\n");
                        i = 150; //reset couters
                        count = 0;
                        continue;
                    }
                }
                if (filei.contains(LineOfInterest)) {
                    count++;
                    if (count == 3 && flags == 3) {
                        deb(filei);
                        String URL = link.split("/v/")[0].split(": ")[1]
                                + filei.split("\"")[1]
                                + (b + 18) //Integer operation, not string concatanation, retard
                                + filei.split("\"")[3];
                        deb(URL);
                        return URL;
                    }
                }
            }
            return null;
        } catch (Exception e) {
            if (debug) {
                e.printStackTrace();
            }
            return null;
        }
    }
}