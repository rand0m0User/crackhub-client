package CrackhubClient.providers;

import CrackhubClient.providers.zippyshareLinkObfuscation.obf1;
import CrackhubClient.providers.zippyshareLinkObfuscation.obf5;
import java.nio.file.Files;
import static CrackhubClient.util.*;

public class zippyshare extends provider {

    //VARS
    private boolean DetectedMethod = false;

    public void test(String link) {
        try {
            URLS = new String[]{"testFile: " + link};
            run(1, false, true, "testFile.bin");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void run(
            int dlt, //DL type, 1 = direct, 2 = batch, 3 = ignore
            boolean quiet, //dont print anything to the console
            boolean nodir, //use program root to download files to
            String outname //name of output file
    ) throws Exception {    //veralog formatting
        DLType = dlt;
        if (DLType == 2) {
            GenerateBat = true;
            BATURLS = new String[URLS.length];
            BATINFO = new String[URLS.length];
        } else {
            GenerateBat = false; //doubble fix
        }
        String out;
        if (UseSystemDownlads) {
            out = "..\\..\\..\\Downloads\\" + outname + "\\";
        } else {
            out = "out\\" + outname + "\\";
        }

        if (!nodir && UseSystemDownlads) {
            createCanonicalFile(out).mkdir();
            save(out + "arc.exe", loadbytearr(".\\tools\\arc.exe"));
            save(out + "unpack.bat", loadbytearr(".\\tools\\unpack.bat"));
            //never forget to actually save an object under a file name
        }

        int counter = 0;
        //int obftype = 0;
        for (int u = 0; u < URLS.length; u++) {
            String fname = URLS[u].split(seperator)[0];
            try {
                if (!Files.exists(createCanonicalFile(out + fname).toPath())) {
                    URL = URLS[u].split(seperator)[1];
                    if (quiet) {
                        print("[zippyshare downloader] fetching page from: " + URL);
                    }
                    curl(URL, "zippyshare.html");
                    String[] file = new String(Files.readAllBytes(createCanonicalFile("zippyshare.html").toPath())).split("\n");

                    //MAIN LOOP
                    //if (obftype == 0) {
                    //simplfied the code to use seprate modules for extracting the real download link from the page
                    for (int i = 1; i < 6; i++) {
                        String str = disbatch(URLS[u], file, i);
                        if (str != null) {
                            if (!DetectedMethod) {
                                print("[zippyshare downloader] link obfuscation method " + i + " detected");
                                //DetectedMethod = true;
                            }
                            //obftype = i;
                            URL = str;
                        }
                    }
                    //} else {
                    //    URL = disbatch(URLS[u], file, obftype);
                    //}
                    if (URL == null) {
                        print("null");
                    }
                    if (GenerateBat) {
                        String tmp = "echo \"" + ProgressBar(URLS.length, counter) + "downloading: " + URL + "\"";
                        BATINFO[counter] = tmp;
                        print("[zippyshare downloader][bat generation] " + tmp);
                    } else {
                        if (quiet) {
                            print(ProgressBar(URLS.length, u) + "downloading: " + URL);
                        }
                    }
                    if (nodir) { //nodir. useed for printing the NFO
                        download(URL, fname);
                    } else {
                        if (desktop) {
                            download(URL, "..\\Downloads\\" + outname + "\\" + fname);
                        } else {
                            download(URL, out + fname);
                        }
                    }

                } else {
                    if (quiet) {
                        print("[zippyshare downloader]" + URLS[u].split(seperator)[0] + " allready exists");
                        BUPos++;
                    }
                }
            } catch (Exception e) {
                print("[zippyshare downloader][WARNING] ignoring: \"" + fname + "\"");
                //counter++;
            }
            counter++;
        }
        if (GenerateBat) {
            String bat = "@echo off\ncolor 0a\n";
            for (int i = 0; i < URLS.length; i++) {
                if (BATINFO[i] != null) {
                    bat += BATINFO[i] + "\n";
                    bat += BATURLS[i] + "\n";
                }
            }
            bat += "pause";
            if (desktop) {
                save("..\\..\\..\\Desktop\\" + outname + "_generated.bat", bat);
            } else {
                save(outname + "_generated.bat", bat);
            }
            BATINFO = null;
            BUPos = 0; // potential fix for a AIOB bug
            BATURLS = null;

            //shellexec("cmd /c run \"..\\..\\..\\Desktop\\" + outname + "_generated.bat\"");
        }
    }

    private void download(String URL, String fileName) throws Exception {
        switch (DLType) {
            case 1:
                curl(URL, fileName);
                break;
            case 2:
                if (desktop) {
                    BATURLS[BUPos] = "..\\Documents\\__NBP_tools_dir__\\curl\\curl -k -L -o \".\\" + fileName + "\" \"" + URL + "\"";
                } else {
                    BATURLS[BUPos] = "..\\..\\__NBP_tools_dir__\\curl\\curl -k -L -o \".\\" + fileName + "\" \"" + URL + "\"";
                }
                BUPos++;
                break;
            case 3:
                break;
            //default:
            //print(curld(URL, fileName));
        }
    }

//    //old method for deobfuscateing the download URL
//    private static void solvemath(String in) throws Exception {
//        String domain = URL.split(OldDomainSeperator)[0];
//        String[] parts = in.split("\"");
//        String[] SMP = parts[2].replace("(", "").replace(")", "").split(" ");
//        int solved = Integer.valueOf(SMP[2]) % Integer.valueOf(SMP[4]) + Integer.valueOf(SMP[6]) % Integer.valueOf(SMP[8]);
//        URL = domain + parts[1] + solved + parts[3];
//    }


    private static String disbatch(String url, String[] page, int o) {
        switch (o) {
            case 1:
                return obf1.getlink(url, page);
            case 2:
                return null;
            case 3:
                return null;
            case 4:
                return null;
            case 5:
                return obf5.getlink(url, page);
            default:
                print("[zippyshare downloader][ERROR]: otype:" + o + " not supported");
                return null;
        }
    }
}
