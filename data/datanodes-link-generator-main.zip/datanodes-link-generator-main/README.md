# Datanodes Link Generator

Put all links in links.txt and then it will generate the download links in the current directory.

How to run with Python:
- Install Python from [here](https://www.python.org/downloads/)
- Run install_dependencies
- Put download links in links.txt
- Run the script with python

How to run compiled version:
- Put download links in links.txt
- Run the executable
