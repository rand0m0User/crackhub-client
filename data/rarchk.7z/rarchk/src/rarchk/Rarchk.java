package rarchk;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Rarchk {

    public static void main(String[] args) throws Exception {
        Files.walk(Paths.get(".\\"), FileVisitOption.FOLLOW_LINKS).filter((t) -> {
            return t.toString().toLowerCase().contains(".rar") | t.toString().toLowerCase().contains(".bin");
        }).forEach((p) -> {
            try {
                File rar = new File(p.toUri());
                String fname = rar.getName();
                String ext = "";
                int dotIndex = fname.lastIndexOf('.');
                if (dotIndex > 0 && dotIndex < fname.length() - 1) {
                    ext = fname.substring(dotIndex + 1);
                }
                long len = rar.length();

                if (len != 524288000 && ext.equals("rar")) {
                    DataInputStream dis = new DataInputStream(new FileInputStream(rar));
                    dis.skip(len - 28);
                    int md5str = dis.readInt();
                    if (md5str == 1296315648) {
                        System.out.println("last rar looks fine \"" + p + "\"");
                        return;
                    } else {
                        if (len > 524288000) {
                            DataInputStream dis2 = new DataInputStream(new FileInputStream(rar));
                            dis2.skip(len - 8);
                            long zeros = dis2.readLong();
                            if (zeros != 0) {
                                System.out.println("incomplete extra file! \"" + p + "\", " + zeros);
                                return;
                            }
                            return;
                        } else {
                            System.out.println("incomplete extra file! \"" + p + "\", ");
                            return;
                        }
                    }
                }
                if (ext.equals("bin")) {
                    DataInputStream dis = new DataInputStream(new FileInputStream(rar));
                    dis.skip(len - 25);
                    int lzmastr = dis.readInt();
                    if (lzmastr == 1819962721) {
                        System.out.println("extra bin looks fine. \"" + p + "\"");
                    } else {
                        //Files.delete(p);
                        System.out.println("incomplete file! \"" + p + "\", " + lzmastr);
                    }
                }
                System.out.println("length:" + rar.length() + " \"" + p + "\"");
            } catch (Exception ex) {
            }
        });
    }
}
