package crackhubclient.providers;

import static crackhubclient.Util.*;
import java.nio.file.Files;

public class Krakenfiles extends Provider {

    static {
        INFOHEADER = "[krakenfiles downloader]";
    }

//    @Override
//    public void test(String link) {
//        try {
//            URLS = new String[]{"testFile: " + link};
//            run(1, false, true, "testFile.bin");
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
//    }
    @Override
    public void run(
            int dlt, //DL type, 1 = direct, 2 = batch, 3 = curl spam
            boolean quiet, //dont print anything to the console
            boolean ndir, //use program root to download files to
            String outname //name of output file
    ) throws Exception {    //veralog formatting
        nodir = ndir; //nodir. useed for printing the NFO
        dLType = dlt;
        if(dLType == 2 || dLType == 3){
            SetDesktop();
            prepareOutFolder(outputFolder);
        }
        if (dLType == 2) {
            generateBat = true;
            BATURLS = new String[URLS.length];
            BATINFO = new String[URLS.length];
        } else {
            generateBat = false; //doubble fix
        }

        int counter = 0;
        for (int u = 0; u < URLS.length; u++) {
            String fname = URLS[u].split(seperator)[0];
            try {
                if (!Files.exists(createCanonicalFile(outputFolder + fname).toPath())) {
                    String url = URLS[u].split(seperator)[1];
                    if (quiet) {
                        print(INFOHEADER + " fetching page from: " + url);
                    }
                    //MAIN LOOP
                    print(INFOHEADER + " executing python module with arguments: " + url);
                    url = advShellexec("python \"python modules\\krakenfiles resolver\\command_line.py\" " + url).trim();
                    print(INFOHEADER + " python module returned: " + url);
                    if (url == null) {
                        print(INFOHEADER + "[ERROR]: URL == null");
                    }
                    if (generateBat) {
                        BATINFO[counter] = String.format("echo \"%s downloading: %s\"", ProgressBar(URLS.length, counter), url);
                        print(String.format("%s[bat generation] %s", INFOHEADER, BATINFO[counter]));
                    } else {
                        if (quiet) {
                            print(String.format("%s %s downloading: %s", INFOHEADER, ProgressBar(URLS.length, u), url));
                        }
                    }
                    download(url, fname, outname );
                } else {
                    if (quiet) {
                        print(String.format("%s[INFO] %s allready exists", INFOHEADER, URLS[u].split(seperator)[0]));
                        bUPos++;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                print(INFOHEADER + "[WARNING] ignoring: \"" + fname + "\"");
            }
            counter++;
        }
        if (generateBat) {
            saveBat(outname);
        }
    }
}
